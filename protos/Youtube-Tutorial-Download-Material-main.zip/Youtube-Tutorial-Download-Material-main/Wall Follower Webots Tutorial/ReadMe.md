This proto contains a rectangel arena and few walls to make a maze.

# Version
This Proto node was made in Webots R2020b.

# How to use this?
Make sure to add this file to the PROTO folder of your project for use.
In your project, create a new world.
Click on "+" to add a node.
Select PROTO nodes (Current Project) > WorldMaze > Click Add.
Similarly, make sure to add TexturedLight and TexturedBackground.

# Tutorial Video Link
<TODO>
  
